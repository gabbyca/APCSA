import java.util.*;

public class Main {
    public static void main(String[] args) {

        hours bulb1 = new hours(true, "Lowe's", 4);


        bulb1.figureOut();
        bulb1.pickOne();
        bulb1.arrStuff();




        System.out.println(bulb1.toString());
        System.out.println(bulb1.arrStuff());



    }
}