public class person {

    //USED FOR UNIT 2 EXAMPLE - DISREGARD

    private boolean gender;
    private int age;

    public person(boolean male, int a){

        gender = male;
        age = a;
    }

    public int getAge() {
        return age;
    }

    public boolean getGender(){
        return gender;
    }


}
