public class lightBulb {

    private boolean LED;
    private String brand;
    private int hoursLast;

    public lightBulb(boolean l, String b){
            LED = l;
            brand = b;
    }
    String isTrue ="";
    public void figureOut(){
        if (LED)
            isTrue = " is LED";
        else {
            isTrue = " is not LED";
        }
    }


    public String toString(){
            return "The light-bulb from " + brand + isTrue;

    }




}
