import java.util.*;

// While Loops
// For Loops
// String Traversals
// String Algorithms
// Nested Iterations
// Tracing
